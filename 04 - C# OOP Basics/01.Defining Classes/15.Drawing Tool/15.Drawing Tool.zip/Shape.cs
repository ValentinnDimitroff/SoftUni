﻿namespace DrawingTool
{
    public abstract class Shape
    {
        public abstract void Draw();
    }
}
