﻿namespace MordorsCrueltyPlan.Foods
{
    public class Melon : Food
    {
        public Melon()
            : base(1)
        {
        }
    }
}
