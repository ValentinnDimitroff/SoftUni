﻿namespace MordorsCrueltyPlan.Foods
{
    public class Apple : Food
    {
        public Apple() 
            : base(1)
        {
        }
    }
}
