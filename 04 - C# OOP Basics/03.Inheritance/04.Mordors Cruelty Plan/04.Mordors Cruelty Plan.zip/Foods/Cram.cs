﻿namespace MordorsCrueltyPlan.Foods
{
    public class Cram : Food
    {
        public Cram()
            :base(2)
        {
        }
    }
}
