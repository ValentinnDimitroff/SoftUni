﻿namespace MordorsCrueltyPlan.Foods
{
    public class Lembas : Food
    {
        public Lembas()
            : base(3)
        {
        }
    }
}
