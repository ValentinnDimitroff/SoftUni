﻿namespace MordorsCrueltyPlan
{
    public class Gandalf
    {
        private int happiness;

        public int Happiness
        {
            get { return this.happiness; }
            set { this.happiness = value; }
        }
    }
}
