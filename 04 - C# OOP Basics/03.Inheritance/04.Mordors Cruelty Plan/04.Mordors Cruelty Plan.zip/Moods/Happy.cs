﻿namespace MordorsCrueltyPlan.Moods
{
    public class Happy : Mood
    {
        public Happy()
            : base("Happy")
        {
        }
    }
}
