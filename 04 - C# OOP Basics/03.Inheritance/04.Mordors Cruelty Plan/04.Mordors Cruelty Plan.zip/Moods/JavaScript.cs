﻿namespace MordorsCrueltyPlan.Moods
{
    public class JavaScript : Mood
    {
        public JavaScript() 
            : base("JavaScript")
        {
        }
    }
}
