﻿namespace _03.Wild_Farm
{
    public abstract class Felime : Mammal
    {
        protected Felime(string name, string type, double weight, string livingRegion) : base(name, type, weight, livingRegion)
        {
        }
    }
}
